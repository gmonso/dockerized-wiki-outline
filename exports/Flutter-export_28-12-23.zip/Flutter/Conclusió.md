# 🧠 Conclusió

## Comunitat Flutter

Formar part d'una comunitat dedicada a Flutter ha estat una experiència altament positiva per a mi. La col·laboració i l'intercanvi de coneixements amb altres desenvolupadors apassionats per aquest framework ha sigut enriquidor i m'ha proporcionat suport durant el meu viatge de desenvolupament.

## Desenvolupament amb Flutter

Desenvolupar amb Flutter al llarg del temps m'ha permès apreciar el gran avanç en la capacitat de desplegar aplicacions en més plataformes. A més, he observat la notable evolució en el desenvolupament de jocs, oferint un abast més ampli d'opcions per als desenvolupadors que busquen crear experiències interactives i divertides.

## Col·laboració amb Google

M'agrada la forma com Google gestiona les contribucions a Flutter. L'apertura a la col·laboració i la transparència en el procés de presa de decisions ofereix un entorn propici per al creixement i la millora contínua del framework.

## Estadístiques de JetBrains

Les estadístiques de JetBrains no fallen, i aquestes indiquen que Flutter té un futur prometedor. Les eines de desenvolupament i el suport continuat de la comunitat i les empreses com JetBrains reforcen la confiança en la sostenibilitat i el creixement de Flutter com a tecnologia.


## Resum

**En resum, la meva experiència amb Flutter és positiva i estic entusiasmat amb les oportunitats que aquest framework ofereix tant en el present com en el futur.**
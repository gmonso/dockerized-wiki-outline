# ℹ️ Informació bàsica

![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/0dcc08de-1e28-441a-84cd-65276ac3195c/image.png "full-width")

## ℹ Que es Flutter ?

Flutter és un framework de desenvolupament de programari multiplataforma basat en el llenguatge de programació Dart. 

És de codi obert i va ser creat per Google al 2015. ![Flutter logo](uploads/39a18299-08be-4f34-bc95-852d818a2a72/55d14f47-49f1-44e1-8368-783a3d99c9a3/image.png "right-50")

S'utilitza per desenvolupar aplicacions per a mòbils, web i escriptori de forma nativa. Ha estat utilitzat com el mètode principal per crear aplicacions per a Google Fuchsia. 

De forma resumida, podríem dir que amb una única base de codi, pots crear aplicacions que funcionen tant en Android, iOS, Linux, Web o Windows.


\
 ![Flutter previsualització aplicacions.](uploads/39a18299-08be-4f34-bc95-852d818a2a72/d36a50c0-b7ed-4ee1-84ce-8d5767e54f67/image.png)


\
## 📋 Característiques

### **Desenvolupament d'Aplicacions Mòbils i Web**

Flutter permet als desenvolupadors crear aplicacions per a plataformes mòbils com Android i iOS, així com per al web.


\
 ![Flutter multiplataforma](uploads/39a18299-08be-4f34-bc95-852d818a2a72/f6d339b0-7a40-495d-84d0-4c307688f8c5/image.png " =224x174")


### **Llenguatge de Programació Dart**

Flutter utilitza Dart com a llenguatge de programació principal. Dart és un llenguatge modern i eficient que ofereix rendiment de primer nivell.


\
 ![Icona llenguatge de programació Dart](uploads/39a18299-08be-4f34-bc95-852d818a2a72/810b70dc-54d9-4f6b-959b-a9dd78b2b7a0/image.png " =134x134")


### **Interfície d'Usuari Expressiva**

Flutter fa servir un sistema de widgets personalitzable que permet als desenvolupadors crear interfícies d'usuari riques i atractives. Els widgets són components d'interfície que es poden personalitzar i combinar per crear dissenys complexos.

### **Hot Reload**

Una de les característiques més potents de Flutter és la capacitat de recarregar codi en temps real (Hot Reload). Això permet als desenvolupadors veure immediatament els canvis realitzats al codi sense reiniciar l'aplicació, accelerant així el procés de desenvolupament.


 ![Flutter hot reload](uploads/39a18299-08be-4f34-bc95-852d818a2a72/64879ab7-4410-4481-846b-43ef6a4af02d/image.png " =314x177")


### **Rendiment Elevat**

Gràcies al seu motor de renderització, Flutter ofereix un rendiment d'alta qualitat. Les aplicacions desenvolupades amb Flutter poden proporcionar una experiència d'usuari fluida i ràpida.

### **Compatibilitat amb Plataformes**

Flutter és compatible amb múltiples plataformes, el que significa que el codi pot ser compartit entre diferents dispositius i sistemes operatius, reduint així el temps i els esforços de desenvolupament.

### **Comunitat Activa**

Flutter gaudeix d'una comunitat de desenvolupadors activa i en creixement. Això significa que hi ha molts recursos, tutorials i ajuda disponibles per als desenvolupadors que treballen amb Flutter.


 ![Comunitats de Flutter arreu del món](uploads/39a18299-08be-4f34-bc95-852d818a2a72/c5b25513-27a7-4d9d-b516-a981098b4268/image.png " =269x216")


### **Suport a API nativa**

Flutter permet als desenvolupadors accedir a les funcionalitats natives dels dispositius a través de plugins, permetent integrar fàcilment característiques com la càmera, la ubicació i altres serveis del sistema operatiu.


\
## 🛠️ Requisits d'Instal·lació

### Windows

#### Sistema Operatiu

* Windows 7 o superior (64 bits)

#### Eines de Desenvolupament


1. **Git:** Instal·lar Git per a la gestió de codi font.
   * Descàrrega: [Git](https://git-scm.com/download/win)
2. **PowerShell:** Utilitzat per a executar scripts i comandes.
   * Ja inclòs en Windows 7 i versions posteriors.

#### Dependències


1. **Visual Studio Code (Opcional):** Un entorn de desenvolupament recomanat.
   * Descàrrega: [VS Code](https://code.visualstudio.com/download)
2. **Android Studio (Opcional):** Per a desenvolupament Android.
   * Descàrrega: [Android Studio](https://developer.android.com/studio)

### macOS

#### Sistema Operatiu

* macOS 10.14 (Mojave) o superior

#### Eines de Desenvolupament


1. **Xcode:** Necessari per a desenvolupament iOS.
   * Descàrrega: [Xcode](https://apps.apple.com/us/app/xcode/id497799835)
2. **Homebrew (Opcional):** Facilita la instal·lació d'eines addicionals.
   * Comanda d'instal·lació: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`

#### Dependències


1. **Visual Studio Code (Opcional):** Un entorn de desenvolupament recomanat.
   * Descàrrega: [VS Code](https://code.visualstudio.com/download)
2. **Android Studio (Opcional):** Per a desenvolupament Android.
   * Descàrrega: [Android Studio](https://developer.android.com/studio)

### Linux

#### Sistema Operatiu

* Distribucions Linux basades en Debian (Ubuntu, etc.)

#### Eines de Desenvolupament


1. **Git:** Instal·lar Git per a la gestió de codi font.
   * Comanda d'instal·lació: `sudo apt-get install git`
2. **Snap (Opcional):** Pot ser útil per a instal·lar eines com Visual Studio Code.
   * Comanda d'instal·lació: `sudo apt-get install snapd`
3. **Shell Zsh (Opcional):** Pot millorar l'experiència d'ús.
   * Comanda d'instal·lació: `sudo apt-get install zsh`

#### Dependències


1. **Visual Studio Code (Opcional):** Un entorn de desenvolupament recomanat.
   * [Instruccions d'instal·lació](https://code.visualstudio.com/docs/setup/linux)
2. **Android Studio (Opcional):** Per a desenvolupament Android.
   * Descàrrega: [Android Studio](https://developer.android.com/studio)
# 📈 Objectius i motivacions

![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/c461a136-da36-4ae3-b414-7e8c44a25549/image.png "full-width")

## Interès en Flutter

La nostra exploració de Flutter esdevé fonamental pel desenvolupament dels nostres membres. El Gerard, actualment immers en el seu Treball de Fi de Grau (TFG), ha optat per utilitzar Flutter com a framework central per al seu projecte. Aquesta decisió posa de manifest el potencial i la confiança en aquesta eina per a projectes acadèmics i professionals. D'altra banda, l'Andreu, qui està a punt de prendre una decisió sobre la seva elecció de framework, trobarà en aquesta anàlisi la guia necessària per comprendre si Flutter compleix amb les seves expectatives i necessitats.

## Pertinença a Google

El fet que Flutter sigui un framework desenvolupat per Google no només indica la seva solidesa, sinó també la possibilitat d'obtenir un suport continuat i actualitzacions rellevants.

## Comunitat Activa

L'existència d'una comunitat àmplia i activa al voltant de Flutter és un element essencial. Aquesta comunitat proporciona un entorn de suport mutu, recursos compartits, i la capacitat d'aprendre i créixer amb altres desenvolupadors.

## Participació del Gerard a la Comunitat

És rellevant destacar que el Gerard no només utilitza Flutter en el marc del seu TFG, sinó que també és un membre actiu de la comunitat de Flutter a Lleida. Aquesta participació directa implica un coneixement pràctic profund del framework i pot oferir una perspectiva única i experiència que podria ser de gran valor.

 ![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/a3fddcc0-9a3f-428f-ace4-8b5c9ca83887/image.png)

## Futur Prometedor

Més enllà de les circumstàncies actuals, ens fixem en el futur de Flutter com una eina amb un potencial notable. Amb la seva capacitat d'encarar altres llenguatges i frameworks, Flutter es presenta com un candidat amb una gran projecció de futur. Aquest factor és una motivació addicional per considerar la nostra desició com a eina de desenvolupament.
# ➕ Contribucions

## Contribució a Flutter

**tl;dr**: Uneix-te a Discord, sigues cortès, seguiu els passos per configurar un entorn de desenvolupament; si continues i contribueixes, pots unir-te a l'equip i obtenir accés de commit. ![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/3a478d37-4a22-423e-bfb7-a5ef573f7b67/image.png "right-50")

Benvinguda Us convidem a unir-vos a l'equip de Flutter, format per voluntaris i patrocinats! Hi ha moltes maneres de contribuir, incloent escriure codi, informar problemes a GitHub, ajudar a la gent als nostres llistats de correu, als nostres canals de xat, o a Stack Overflow, ajudar a triar, reproduir o solucionar errors que la gent ha informat, afegir a la nostra documentació, fer divulgació sobre Flutter, o ajudar de qualsevol altra manera.

Concedim accés de commit (que inclou drets complets a la base de dades d'incidències, com ara editar etiquetes) a aquells que han guanyat la nostra confiança i han demostrat un compromís amb Flutter. Per a més detalls, consulta la pàgina d'accés del contribuent a la nostra wiki.

Comuniquem principalment a través de GitHub i Discord.

Abans de començar, us animem a llegir aquests documents que descriuen algunes de les nostres normes comunitàries:

* [Codi de conducta](https://github.com/flutter/flutter/blob/master/CODE_OF_CONDUCT.md): que especifica explícitament que tothom ha de ser amable, respectuós i professional.
* [Valors](https://github.com/flutter/flutter/wiki/Values): que parla del que ens importa més.

## Ajuda a la Base de Dades d'Incidències

**Triage** és el procés de revisar els informes d'errors i determinar si són vàlids, com reproduir-los, detectar informes duplicats, i fer útil la nostra llista d'incidències per als nostres enginyers.

Si vols ajudar-nos en això, ets benvingut!


1. Uneix-te al canal Discord **#hackers-triage**.
2. Llegeix el nostre codi de conducta, ja que, si ajudes amb el triage, representes l'equip de Flutter.
3. Ajuda segons la nostra [wiki](https://github.com/flutter/flutter/wiki/Triage). Al principi no podràs afegir etiquetes, així que comença intentant realitzar altres passos com reproduir el problema i demanar que proporcionin prou detalls per reproduir-lo.
4. Xateja al canal **#hackers-triage** per informar-nos del que estàs fent.

Familiaritza't amb la nostra [pàgina de manteniment d'incidències](https://github.com/flutter/flutter/wiki/Issue-Hygiene), que cobreix els significats d'algunes etiquetes i fites importants de GitHub.

Quan portis fent això un temps, algú t'invitarà a l'equip **flutter-hackers** a GitHub i podràs afegir etiquetes també. Consulta la pàgina de wiki d'accés del contribuent per a més detalls.

## Assegurament de la Qualitat (QA)

Una de les tasques més útils, estretament relacionada amb el triage, és trobar i informar errors. Provar versions beta, buscar regressions, crear casos de prova, afegir al nostre conjunt de proves i altres treballs similars poden millorar la qualitat del producte. Contribuir amb tests que augmentin la nostra cobertura de proves, escriure proves per a problemes que d'altres han informat, totes aquestes tasques són contribucions molt valuoses als projectes de codi obert.

Si això t'interessa, pots començar a enviar informes d'errors sense necessitat de cap permís! El canal Discord **#quality-assurance** és un bon lloc per parlar del que estàs fent. Estem especialment desitjosos de fer proves de QA quan anunciem una versió beta. Consulta [aquesta pàgina](https://github.com/flutter/flutter/wiki/Quality-Assurance) per a més detalls.

Si vols contribuir amb casos de prova, també pots enviar PRs. Consulta la secció següent sobre com configurar el teu entorn de desenvolupament, o pregunta al Discord al canal **#hackers-test**.

Com a nota personal, aquesta és exactament la mena de feina que em va portar per primer cop a l'open source. Vaig ser voluntari de QA al projecte Mozilla, escrivint casos de prova per als navegadors, molt abans d'escriure cap línia de codi per a cap projecte de codi obert. —Hixie

## Desenvolupament per Flutter

Si prefereixes escriure codi, potser voldràs començar amb la nostra llista de **bons primers problemes** per Flutter o per les **Flutter DevTools**. Consulta les seccions respectives a continuació per a més instruccions.

### Framework i Engine

Per desenvolupar per Flutter, eventualment hauràs de familiaritzar-te amb els nostres processos i convencions. Aquesta secció llista els documents que descriuen aquestes metodologies. La llista següent està ordenada: es recomana encaridament que vagis per aquests documents en l'ordre presentat.


1. [Configurar el teu entorn de desenvolupament de l'engine](https://github.com/flutter/flutter/wiki/Setting-up-the-Engine-development-environment): descriu els passos per configurar el teu ordinador per treballar a l'engine de Flutter. Si només vols escriure codi pel framework de Flutter, pots saltar aquest pas. L'engine de Flutter utilitza principalment C++, Java i Objective-C.
2. [Configurar el teu entorn de desenvolupament del framework](https://github.com/flutter/flutter/wiki/Setting-up-the-Framework-development-environment): descriu els passos per configurar el teu ordinador per treballar al framework de Flutter. El framework de Flutter utilitza principalment Dart.
3. [Higiene de l'estructura](https://github.com/flutter/flutter/wiki/Tree-hygiene): cobreix com ater
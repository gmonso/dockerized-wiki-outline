# 📚 Documentació

La documentació de Flutter, la guia completa per als desenvolupadors que desitgen crear aplicacions multiplataforma amb facilitat i eficàcia. A continuació, un resum dels continguts més destacats:


 ![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/4d8a42f2-3834-4047-80b4-fd63899fb5ef/image.png "right-50")

## Començar

Si ets nou a Flutter, [comença aquí](https://flutter.dev/docs/get-started) per obtenir tota la informació necessària per configurar i començar a desenvolupar amb Flutter.


## Mostres i codelabs

Explora [mostres i codelabs](https://flutter.dev/docs/codelabs) per aprendre i practicar amb Flutter. Desenvolupa habilitats essencials i apren noves tècniques.

## Solucions d'aplicacions

Descobreix [solucions pràctiques](https://flutter.dev/docs/solutions) per a diferents aspectes del desenvolupament d'aplicacions amb Flutter, com el disseny, la navegació i la integració de plataformes.

## Conceptes de Flutter

Entén els [conceptes fonamentals de Flutter](https://flutter.dev/docs/development/ui/widgets), com ara els widgets, el disseny, la interactivitat i altres temes clau per desenvolupar amb aquest framework.

## Preguntes freqüents (FAQ)

Obtén respostes a [preguntes freqüents sobre Flutter](https://flutter.dev/docs/resources/faq) i resol dubtes comuns mentre desenvolupes les teves aplicacions.

## Vídeos

Segueix la sèrie "[Introducing Flutter](https://flutter.dev/docs/resources/videos)" per aprendre conceptes bàsics i consells útils sobre el desenvolupament amb Flutter.

## Recursos

Explora una [llista de recursos addicionals](https://flutter.dev/docs/resources) per mantenir-te informat i ampliar els teus coneixements sobre Flutter.

La documentació de Flutter és una eina essencial per als desenvolupadors que busquen comprendre i utilitzar eficaçment aquest framework innovador.
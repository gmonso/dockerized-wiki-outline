# 👨‍💻 Comunitat

Flutter és molt més que un framework, és una comunitat oberta a tothom, on desenvolupadors de tot el món col·laboren per fer de Flutter una eina cada vegada millor i més àmpliament utilitzada. ![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/bc43a5bd-4927-480a-a5bf-f97f5e8445af/image.png "right-50")

Amb més de 155.000 estrelles a GitHub, 240.000 seguidors a Twitter i 175.000 membres als Meetups, Flutter s'ha consolidat com el framework multiplataforma més popular, com es demostra a través de l'enquesta JetBrains 2021 State of Developer Ecosystem.

## Grups de la Comunitat

En el cor de la comunitat Flutter es troben diversos grups que ofereixen oportunitats úniques:

### Meetups

Troba un grup de meetup a prop teu i connecta amb altres desenvolupadors Flutter. Assisteix a presentacions, comparteix coneixements i fes xarxa amb altres professionals.

### Flutter GDEs

Converteix-te en un Flutter Google Developer Expert (GDE) i converteix-te en un líder reconegut. Proporciona suport a l'ecosistema Flutter i gaudeix d'avantatges exclusius.

### Flutteristas

Uneix-te a les Flutteristas, una comunitat acollidora per a persones que s'identifiquen com a dones o no binàries amb un interès comú en Flutter. Proporciona suport, col·labora i crea connexions significatives.

## Esdeveniments de la Comunitat

Flutter va més enllà de les línies de codi i ofereix una experiència completa amb esdeveniments locals, virtuals i internacionals.

Assisteix a esdeveniments organitzats per la comunitat global de Flutter, on podràs conèixer experts, obtenir consells i connectar amb altres apassionats de Flutter.

### Flutter Algeria

Descobreix més sobre aquest esdeveniment local a Satif, Algèria, i participa en activitats i xerrades de la comunitat.

## Cultura de Flutter

Flutter esforça-se per mantenir tots els seus espais comunitaris acollidors, respectuosos i inclusius. Aprèn més sobre la cultura de la comunitat Flutter i com pots contribuir al seu manteniment.

## Alimentat per Dart

Segueix les últimes notícies de Flutter i Dart, la llengua de programació que impulsa aquest framework.

## Plataformes de Comunitat

* Flutter Discord
* Community Slack
* Stack Overflow
* Reddit
* Google Developer Groups
* Flutter Groups

## Canvis Importants

Mantingues-te informat sobre les darreres actualitzacions i canvis importants directament a la teva safata d'entrada. Subscriu-te al butlletí de Flutter per rebre notificacions i consells útils.

La comunitat de Flutter no només és un lloc per aprendre i créixer com a desenvolupador, sinó també un entorn acollidor on les connexions i les amistats poden florir. Uneix-te a nosaltres i fes que Flutter sigui una part integral del teu viatge de desenvolupament.
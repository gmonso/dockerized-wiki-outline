# 🔱 Repositori

El repositori de Flutter conté el codi font del framework i les eines relacionades per al desenvolupament d'aplicacions multiplataforma. Algunes carpetes importants inclouen:

* **packages:** Conté els paquets del framework que proporcionen funcionalitats específiques.
* **examples:** Inclou exemples d'aplicacions per demostrar les característiques de Flutter.
* **dev:** Conté eines i scripts per al desenvolupament intern de Flutter.

## Llenguatge Dart

Flutter utilitza el llenguatge de programació Dart. Algunes característiques notables de Dart inclouen:

* Tipat fort
* Recollida d'escombraries (garbage collection)
* Suport per a programes asincrònics amb futurs i corutines.

## Integració d'Issues amb GitHub Projects

Les issues (problemes) del repositori de Flutter estan integrades amb GitHub Projects per millorar la gestió del desenvolupament. Això permet als desenvolupadors organitzar i seguir el progrés dels problemes utilitzant taules de projectes.

### GitHub Projects

* **Taula de Backlog:** Conté les issues pendents que encara no han començat.
* **Taula de Treball en Curs:** Les issues en les quals els desenvolupadors estan actualment treballant.
* **Taula de Fet:** Conté les issues que s'han completat amb èxit i estan llestes per a la revisió.

Aquesta integració millora la transparència i la col·laboració entre els membres del projecte.

Per obtenir més detalls i informació, podeu visitar el [repositori de Flutter a GitHub](https://github.com/flutter/flutter).

## Wiki

La wiki conté documentació extensa sobre el desenvolupament amb Flutter. Trobaràs informació sobre com començar, configurar l'entorn de desenvolupament, com contribuir, i molts altres recursos útils per als desenvolupadors. ![](uploads/39a18299-08be-4f34-bc95-852d818a2a72/f5f5f819-86ea-40d3-9b5d-4b891eddbdeb/image.png "right-50")

## CI/CD (Integració contínua i Desplegament contínu)

La secció CI/CD mostra l'estat de la integració contínua i els processos de desplegament contínu del projecte. Pots veure l'estat actual de les proves i altres passes de construcció.

* <https://flutter-gold.skia.org/changelists>
* <https://flutter-dashboard.appspot.com/#/build>

## Contribuïdors

La secció de persones mostra els membres del projecte Flutter. Aquí pots trobar els desenvolupadors i col·laboradors que han contribuït al projecte.

## Projectes Destacats

### Flutter Framework

El cor del desenvolupament d'aplicacions amb Flutter. Inclou el codi font principal, les eines i les llibreries essencials per construir aplicacions multiplataforma amb una única base de codi.

[Enllaç al Repositori](https://github.com/flutter/flutter)

### Flutter Engine

El motor que impulsa Flutter. Conté el nucli del motor de representació gràfica, interacció amb l'usuari i altres components fonamentals per garantir un rendiment òptim en totes les plataformes.

[Enllaç al Repositori](https://github.com/flutter/engine)

### Flutter Samples

Una col·lecció de mostres i exemples de codi per ajudar els desenvolupadors a aprendre i entendre com implementar diverses funcionalitats amb Flutter. Des de les bases fins a les característiques avançades.

[Enllaç al Repositori](https://github.com/flutter/samples)

### Flutter Gallery

Una aplicació de galeria d'exemple que demostra les capacitats visuals i d'interacció de Flutter. És una eina excel·lent per explorar el potencial de disseny i funcionalitat del framework.

[Enllaç al Repositori](https://github.com/flutter/gallery)

### Flutter Website

El codi font del lloc web oficial de Flutter. Inclou documentació, tutorials i recursos per ajudar els desenvolupadors a navegar i aprendre sobre Flutter.

[Enllaç al Repositori](https://github.com/flutter/website)

##
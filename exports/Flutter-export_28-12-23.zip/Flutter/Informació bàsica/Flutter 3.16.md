# ⚙️ Flutter 3.16

> [Flutter 3.16](https://medium.com/flutter/whats-new-in-flutter-3-16-dba6cb1015d1)

## **🚀 Novetats**

* **Flutter 3.16 Llançat:** La versió més recent de Flutter, la 3.16, ja està disponible.
* **Tema Predeterminat de Material 3:** A partir d'aquesta versió, el tema predeterminat per a les aplicacions Flutter Material és Material 3. Si no especifiques explícitament Material 2 amb **useMaterial3: false** al tema de la teva aplicació, aquesta tindrà un aspecte diferent després d'actualitzar.
* **Actualització del Flutter Casual Games Toolkit:** Tot i que no és tècnicament part de la versió 3.16, s'ha alliberat una actualització significativa del Flutter Casual Games Toolkit. Aquesta inclou tres plantilles de codi de jocs completament noves, tres noves receptes del recull de cuina per a jocs i una reorganització general de la documentació del kit de jocs. Per a més informació, consulta el Flutter Casual Games Toolkit i assegura't de mirar la navegació lateral!
* **Impeller Runtime per a Dispositius Android amb Vulkan:** El motor de renderització Impeller ara està disponible per a dispositius Android amb Vulkan darrere de la bandera **--enable-impeller**.
* **Afegir Extensions d'Aplicacions Apple iOS:** Ara pots afegir extensions d'aplicacions Apple iOS a la teva aplicació Flutter quan s'executa a iOS.


## **⏭ Pròximament**

* **Material 3:** Material 3 s'habilitarà de manera predeterminada a la pròxima versió estable. És hora de començar a migrar el codi.
* **Impeller per a Android:** Progrés continu en Impeller per a Android.
* **Noves APIs de desplaçament:** S'està treballant en l'actualització de les APIs de desplaçament, incloent suport de desplaçament 2D per a arbres i taules, fins i tot desplaçament diagonal.
* **Actualitzacions al Flutter Games Toolkit:** S'està treballant en actualitzacions per al Flutter Games Toolkit, incloent codi d'exemple, documentació addicional i un nou vídeo.


\
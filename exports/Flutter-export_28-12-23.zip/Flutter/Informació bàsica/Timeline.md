# ⌛ Timeline

## **2015**

Flutter va ser introduït per primera vegada sota el nom de "Sky" el 2015 i va ser implementat inicialment en el sistema operatiu Android. La seva revelació va tenir lloc durant la cimera de desenvolupadors Dart el mateix any, amb l'objectiu declarat de poder renderitzar de manera consistent a 120 fotogrames per segon.

## **2017**

El 2017 va marcar un moment clau per Flutter, ja que va ser llançat oficialment com a producte de la divisió d'enginyeria de Chrome de Google. Aquest moviment va confirmar la dedicació de Google al desenvolupament d'aquest nou framework.

## **2018**

El 4 de desembre de 2018, es va produir un esdeveniment crucial amb el llançament de la primera versió estable de Flutter, la versió 1.0. Aquesta fita va ser assenyalada com a un èxit significatiu per a la comunitat de desenvolupadors i va consolidar la posició de Flutter com a framework prometedor.

## **2019**

El 11 de desembre de 2019, en l'esdeveniment Flutter Interactive, es va presentar Flutter 1.12, que va aportar millores i noves funcionalitats al framework. Aquesta actualització va mantenir el momentum del creixement de Flutter i va subratllar el compromís continu de Google amb el seu desenvolupament.

En aquests primers anys, Flutter va establir-se com un framework emergent amb un enfocament singular en la creació d'interfícies d'usuari atractives i eficients. La seva evolució i adopció continuada durant aquest període van establir les bases per a les futures expansions i millores que es produirien en els anys successius.

## **2020**

Després del llançament de Flutter 1.17.0 i el kit de desenvolupament de programari Dart 2.8 el 6 de maig de 2020, Google va introduir diverses millores significatives. Aquesta versió va afegir suport per a l'API Metal, millorant el rendiment en dispositius iOS en un 50%. A més, s'inclogueren nous widgets de Material i eines de desenvolupament per al seguiment de la xarxa.

## **2021**

El 3 de març de 2021, durant l'esdeveniment virtual anomenat "Flutter Engage", Google va presentar Flutter 2, marcant un canvi important en el SDK. Aquesta actualització va portar el suport oficial per a aplicacions basades en web amb un nou renderitzador anomenat Canvas Kit i widgets específics per a la web. També s'introduïren funcionalitats d'aplicació de sobretaula en accés anticipat per a Windows, macOS i Linux, així com millores en les APIs Add-to-App.

## **2022**

El 12 de maig de 2022, Google va anunciar Flutter 3 i Dart 2.17, ampliant el nombre total de plataformes suportades a sis. Aquesta actualització va incorporar el suport estable per a Linux i macOS en processadors tant d'Intel com d'Apple Silicon, consolidant la presència de Flutter en un ventall encara més ampli d'entorns de desenvolupament.

El 30 d'agost de 2022, es va presentar Flutter 3.3, amb la incorporació d'interopositivitat amb Objective-C i Swift, així com una previsualització inicial d'un nou motor de renderització anomenat "Impeller". Aquest motor té com a objectiu reduir els contratemps causats per la compilació de shaders, millorant encara més la fluidesa i la eficiència de les aplicacions desenvolupades amb Flutter.

## **2023**

El 25 de gener de 2023, es va anunciar Flutter 3.7, mostrant el compromís continu de Google amb el desenvolupament i millora constants del framework. Aquesta actualització probablement va incloure millores en rendiment, nous widgets i funcionalitats, demostrant la capacitat de Flutter d'adaptar-se als canvis i les necessitats emergents del món del desenvolupament d'aplicacions. La comunitat estava impacient per descobrir les novetats i les millores que Flutter 3.7 portaria al món de la programació d'aplicacions.
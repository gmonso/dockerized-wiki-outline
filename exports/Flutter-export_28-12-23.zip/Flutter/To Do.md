# To Do

[https://docs.google.com/document/d/1oadhhFm5gifR3MvDEjD6iETRqVGQ2zoi8W%5F51Ub5eNs/edit?usp=sharing](https://docs.google.com/document/d/1oadhhFm5gifR3MvDEjD6iETRqVGQ2zoi8W%5F51Ub5eNs/edit?usp=sharing)


\
- [x] Development Support Infrastructure (GERARD)
  - [x] Project repository
  - [x] Communication mechanisms
  - [x] Documentation tools
  - [x] Version control tool
  - [x] Bug tracking tool


- [x] Community (GERARD)
  - [x] Size (small: less than 51; medium: 51-250; large: more than 250)
  - [x] Means for the donation system or other kind of contribution


- [x] Conclusió
  - [x] Gerard
  - [ ] Andreu (revisa-ho)


\

\
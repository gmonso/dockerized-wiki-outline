# 📚 Bibliografía

## 🌍 Webs

* [Flutter](https://flutter.dev/)
* [GSoC 2024 Liquid Galaxy](https://www.liquidgalaxy.eu/2023/09/google-summer-of-code-2024-unique-post.html)
* <https://docs.flutter.dev/>
* <https://github.com/flutter>
* <https://developers.google.com/>
* <https://www.jetbrains.com/lp/devecosystem-2023/languages/>
* \


## 🧾 Articles

* [Com IBM està creant un Centre d'Excel·lència Flutter](https://chat.openai.com/c/db9b9e9f-cb5c-420b-bc20-65b9055b8ecf#)
* [Presentació del Directori de Consultoria Flutter](https://chat.openai.com/c/db9b9e9f-cb5c-420b-bc20-65b9055b8ecf#)
* [Desenvolupament d'aplicacions Flutter per a pantalles grans](https://chat.openai.com/c/db9b9e9f-cb5c-420b-bc20-65b9055b8ecf#)
* [Dart & Flutter DevTools Extensions](https://chat.openai.com/c/db9b9e9f-cb5c-420b-bc20-65b9055b8ecf#)
* [Construint el teu pròxim joc casual amb Flutter](https://chat.openai.com/c/db9b9e9f-cb5c-420b-bc20-65b9055b8ecf#)